# 🔒| Nasıl Kurulur ?

* ``settings.json`` ve ``config.json`` Dosyasındaki Bilgileri Doldurun ! 
* Cmd'ye ``node .`` Veya ``node server.js`` Yazın !
* Modül Hatası Verirse ``npm i`` Yazın !

# 🔒| Özellikleri ?
* Profil Sistemi
* Kod Paylaşma Sistemi
* Modern Tasarım
* Tailwindcss İle Yapıldı
* Admin Panel
* Yetkililerimiz Sayfası
* Kod Editleme Sistemi
